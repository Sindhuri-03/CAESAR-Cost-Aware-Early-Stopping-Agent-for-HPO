"""
analyze_results.py

Builds the comparison table and runs statistical significance tests on
the multi-seed results from run_multi_seed.py.

Why paired tests: the agent and baseline conditions are run on the SAME
seeds (same data split, same Optuna sampler state), so each seed gives a
natural pair (agent_result, baseline_result) — a paired test is more
powerful than an unpaired one here, since it cancels out seed-to-seed
variance that affects both conditions equally.

Why report both a t-test and Wilcoxon: ML HPO experiments typically run
few seeds (3-10), too few to safely assume normality. The paired t-test
is reported because it's the standard/expected test reviewers look for,
but the Wilcoxon signed-rank test (non-parametric, no normality
assumption) is reported alongside it as the more defensible test at
small N. If they agree, that strengthens the result; if they disagree,
that's worth flagging rather than hiding.

Usage:
    python analyze_results.py
"""

import glob
import os
import re

import numpy as np
import pandas as pd
from scipy import stats


RESULTS_DIR = "results/multi_seed"


def load_seed_results():
    """Returns a DataFrame with one row per seed, columns for both
    conditions' final cost and best accuracy."""
    agent_files = sorted(glob.glob(os.path.join(RESULTS_DIR, "agent_seed*.csv")))
    rows = []

    for agent_path in agent_files:
        seed = re.search(r"seed(\d+)", agent_path).group(1)
        baseline_path = os.path.join(RESULTS_DIR, f"baseline_seed{seed}.csv")
        if not os.path.exists(baseline_path):
            print(f"Warning: no matching baseline file for seed {seed}, skipping.")
            continue

        agent_df = pd.read_csv(agent_path)
        baseline_df = pd.read_csv(baseline_path)

        rows.append({
            "seed": int(seed),
            "agent_total_cost": agent_df["trial_cost_usd"].sum(),
            "baseline_total_cost": baseline_df["trial_cost_usd"].sum(),
            "agent_best_accuracy": agent_df["best_val_accuracy"].max(),
            "baseline_best_accuracy": baseline_df["best_val_accuracy"].max(),
            "agent_n_trials": agent_df["trial"].nunique(),
            "baseline_n_trials": baseline_df["trial"].nunique(),
        })

    return pd.DataFrame(rows).sort_values("seed").reset_index(drop=True)


def run_paired_tests(a, b, label):
    """a, b: arrays of paired values (agent, baseline) for one metric."""
    diffs = a - b
    result = {
        "metric": label,
        "agent_mean": np.mean(a),
        "agent_std": np.std(a, ddof=1) if len(a) > 1 else 0.0,
        "baseline_mean": np.mean(b),
        "baseline_std": np.std(b, ddof=1) if len(b) > 1 else 0.0,
        "mean_diff": np.mean(diffs),
    }

    if len(a) < 2:
        result["t_stat"], result["t_pvalue"] = None, None
        result["wilcoxon_stat"], result["wilcoxon_pvalue"] = None, None
        return result

    t_stat, t_p = stats.ttest_rel(a, b)
    result["t_stat"], result["t_pvalue"] = t_stat, t_p

    # Wilcoxon requires at least a few non-zero differences and n>=~5 to be
    # meaningful; guard against degenerate cases (all-zero diffs, too few seeds)
    try:
        if len(a) >= 5 and np.any(diffs != 0):
            w_stat, w_p = stats.wilcoxon(a, b)
            result["wilcoxon_stat"], result["wilcoxon_pvalue"] = w_stat, w_p
        else:
            result["wilcoxon_stat"], result["wilcoxon_pvalue"] = None, None
    except ValueError:
        result["wilcoxon_stat"], result["wilcoxon_pvalue"] = None, None

    return result


def main():
    df = load_seed_results()
    if df.empty:
        print(f"No paired seed results found in {RESULTS_DIR}/. Run run_multi_seed.py first.")
        return

    n = len(df)
    print(f"Loaded {n} paired seed(s): {list(df['seed'])}")
    if n < 3:
        print("WARNING: fewer than 3 seeds. Significance tests below are not "
              "reliable with this few samples — treat any p-values as illustrative "
              "only, and run more seeds (aim for 5+) before citing significance in the paper.\n")

    # ---- comparison table (means ± std across seeds) ----
    cost_test = run_paired_tests(df["agent_total_cost"].values, df["baseline_total_cost"].values, "Total cost (USD)")
    acc_test = run_paired_tests(df["agent_best_accuracy"].values, df["baseline_best_accuracy"].values, "Best accuracy")

    saving_pct = (cost_test["baseline_mean"] - cost_test["agent_mean"]) / cost_test["baseline_mean"] * 100

    print("\n" + "=" * 70)
    print("COMPARISON TABLE (mean ± std across seeds)")
    print("=" * 70)
    print(f"{'Metric':<20}{'Agent-guided':<22}{'Baseline':<22}")
    print(f"{'Total cost ($)':<20}{cost_test['agent_mean']:.4f} ± {cost_test['agent_std']:.4f}"
          f"{'':<6}{cost_test['baseline_mean']:.4f} ± {cost_test['baseline_std']:.4f}")
    print(f"{'Best accuracy':<20}{acc_test['agent_mean']:.4f} ± {acc_test['agent_std']:.4f}"
          f"{'':<6}{acc_test['baseline_mean']:.4f} ± {acc_test['baseline_std']:.4f}")
    print(f"\nCost saving: {cost_test['baseline_mean'] - cost_test['agent_mean']:.4f} USD "
          f"({saving_pct:.1f}%)")

    print("\n" + "=" * 70)
    print("STATISTICAL SIGNIFICANCE (paired, agent vs. baseline, same seeds)")
    print("=" * 70)
    for test in (cost_test, acc_test):
        print(f"\n{test['metric']}:")
        if test["t_pvalue"] is not None:
            print(f"  Paired t-test:      t={test['t_stat']:.4f}, p={test['t_pvalue']:.4f}"
                  f" {'(significant at 0.05)' if test['t_pvalue'] < 0.05 else '(not significant at 0.05)'}")
        else:
            print("  Paired t-test:      not computed (need >=2 seeds)")
        if test["wilcoxon_pvalue"] is not None:
            print(f"  Wilcoxon signed-rank: W={test['wilcoxon_stat']:.4f}, p={test['wilcoxon_pvalue']:.4f}"
                  f" {'(significant at 0.05)' if test['wilcoxon_pvalue'] < 0.05 else '(not significant at 0.05)'}")
        else:
            print("  Wilcoxon signed-rank: not computed (need >=5 seeds with non-zero differences)")

    # ---- save everything for the paper ----
    os.makedirs("results", exist_ok=True)
    df.to_csv("results/per_seed_comparison.csv", index=False)

    summary = pd.DataFrame([
        {"metric": "total_cost_usd", **{k: v for k, v in cost_test.items() if k != "metric"}},
        {"metric": "best_accuracy", **{k: v for k, v in acc_test.items() if k != "metric"}},
    ])
    summary.to_csv("results/statistical_summary.csv", index=False)
    print(f"\nSaved results/per_seed_comparison.csv and results/statistical_summary.csv")


if __name__ == "__main__":
    main()
