import os
import random
import numpy as np
import torch

from config import SEED, RESULTS_DIR
from agent_hpo import run_agent_hpo
from baseline import run_random_baseline
from final_eval import final_test_evaluation
from evaluation import evaluate_results

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def main():
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is not available. Add it through Colab Secrets.")

    seed_everything(SEED)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Device:", device)
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))

    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("\n=== LLM AGENT HPO ===")
    _, agent_df = run_agent_hpo(device)
    if agent_df is None or agent_df.empty:
        raise RuntimeError("No LLM-agent HPO trials completed.")

    print("\n=== RANDOM SEARCH BASELINE ===")
    _, baseline_df = run_random_baseline(device)
    if baseline_df is None or baseline_df.empty:
        raise RuntimeError("No baseline trials completed.")

    print("\n=== HELD-OUT TEST EVALUATION ===")
    test_result = final_test_evaluation(agent_df, device)
    print(test_result)

    print("\n=== FINAL EVALUATION ===")
    summary = evaluate_results(agent_df, baseline_df)
    print(summary)

    print("\nCompleted. Results saved in:", RESULTS_DIR)
    return summary

if __name__ == "__main__":
    main()
