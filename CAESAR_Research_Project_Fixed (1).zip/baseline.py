import os
import pandas as pd
import torch
import optuna

from config import *
from data import get_data_loaders
from model import build_model
from training import make_optimizer, train_one_epoch, evaluate
from cost_tracker import CostTracker

def run_random_baseline(device):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    path = os.path.join(RESULTS_DIR, "random_search_results.csv")

    # Uses the SAME sampler (TPE) as the agent condition in agent_hpo.py,
    # so any cost/accuracy difference is attributable to the early-stopping
    # mechanism, not a different configuration-sampling strategy.
    study = optuna.create_study(
        direction="maximize",
        sampler=optuna.samplers.TPESampler(seed=SEED)
    )

    global_tracker = CostTracker(GPU_PRICE_PER_HOUR)
    records = []

    def objective(trial):
        if global_tracker.total_cost >= TOTAL_BUDGET:
            raise optuna.TrialPruned("Global budget exhausted before trial start.")

        params = {
            "learning_rate": trial.suggest_float("learning_rate", 1e-4, 1e-1, log=True),
            "batch_size": trial.suggest_categorical("batch_size", [32, 64, 128]),
            "optimizer": trial.suggest_categorical("optimizer", ["SGD", "Adam"]),
            "weight_decay": trial.suggest_float("weight_decay", 1e-5, 1e-2, log=True),
        }

        train_loader, val_loader, _ = get_data_loaders(params["batch_size"])
        model = build_model().to(device)
        optimizer = make_optimizer(model, params)
        trial_tracker = CostTracker(GPU_PRICE_PER_HOUR)

        best_acc = -1.0
        reached_target = False

        for epoch in range(1, MAX_EPOCHS + 1):
            if global_tracker.total_cost >= TOTAL_BUDGET:
                break

            train_m = train_one_epoch(model, train_loader, optimizer, device)
            val_m = evaluate(model, val_loader, device)

            trial_tracker.add_seconds(train_m["epoch_seconds"])
            global_tracker.add_seconds(train_m["epoch_seconds"])

            acc = val_m["val_accuracy"]
            best_acc = max(best_acc, acc)
            reached_target = reached_target or acc >= TARGET_ACCURACY

            print(
                f"[baseline] Trial {trial.number:02d} Epoch {epoch:02d} "
                f"acc={acc:.4f} cost=${trial_tracker.total_cost:.5f}"
            )

        records.append({
            "trial": trial.number,
            **params,
            "best_val_accuracy": best_acc,
            "trial_cost_usd": trial_tracker.total_cost,
            "reached_target": reached_target,
            "global_cost_usd_after_trial": global_tracker.total_cost
        })
        return best_acc

    try:
        study.optimize(objective, n_trials=N_TRIALS)
    except KeyboardInterrupt:
        print("Baseline interrupted.")

    df = pd.DataFrame(records)
    df.to_csv(path, index=False)
    return study, df
