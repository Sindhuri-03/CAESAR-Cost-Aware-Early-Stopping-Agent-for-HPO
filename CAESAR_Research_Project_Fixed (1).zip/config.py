import os

SEED = 42

# HPO
N_TRIALS = 15
NOMINAL_EPOCHS = 5
MAX_EPOCHS = 10
TARGET_ACCURACY = 0.70

# Simulated compute budget from the paper's example
TOTAL_BUDGET = 5.00
GPU_PRICE_PER_HOUR = 0.526

# OpenAI model; can be overridden with an environment variable
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")

# Paths
DATA_DIR = "data"
RESULTS_DIR = "results"
CHECKPOINT_DIR = "checkpoints"

TRAIN_SPLIT_SEED = 42
NUM_WORKERS = 2

# None means use the selected trial's best epoch
FINAL_EPOCHS = None
