import json
import os
from openai import OpenAI
from config import LLM_MODEL

class LLMEarlyStoppingAgent:
    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is not available.")
        self.client = OpenAI(api_key=api_key)

    def decide(self, context):
        prompt = f"""You are the cost-aware early-stopping controller in a hyperparameter optimization experiment.

Choose exactly one action:
CONTINUE = continue only within the nominal epoch allowance.
EXTEND = the trial is promising enough to receive the remaining extended training horizon up to max_epoch.
KILL = stop because additional compute is not justified.

Consider validation accuracy, accuracy change, best accuracy, trial cost, global remaining budget, and hyperparameters.

Return ONLY JSON:
{{"action":"CONTINUE|EXTEND|KILL","reason":"one concise sentence"}}

Context:
{json.dumps(context, indent=2)}
"""

        response = self.client.responses.create(
            model=LLM_MODEL,
            input=prompt,
        )
        text = response.output_text.strip()

        try:
            result = json.loads(text)
            action = str(result.get("action", "CONTINUE")).upper()
            reason = str(result.get("reason", "No reason supplied."))
        except Exception:
            action = "CONTINUE"
            reason = "Unparseable agent output; defaulted to CONTINUE."

        if action not in {"CONTINUE", "EXTEND", "KILL"}:
            action = "CONTINUE"

        return action, reason
