import time
import torch
import torch.nn as nn
import torch.optim as optim

def make_optimizer(model, params):
    if params["optimizer"] == "Adam":
        return optim.Adam(
            model.parameters(),
            lr=params["learning_rate"],
            weight_decay=params["weight_decay"]
        )
    return optim.SGD(
        model.parameters(),
        lr=params["learning_rate"],
        weight_decay=params["weight_decay"],
        momentum=0.9
    )

def train_one_epoch(model, loader, optimizer, device):
    model.train()
    criterion = nn.CrossEntropyLoss()
    total_loss = correct = total = 0
    start = time.perf_counter()

    for x, y in loader:
        x = x.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        output = model(x)
        loss = criterion(output, y)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * y.size(0)
        correct += (output.argmax(1) == y).sum().item()
        total += y.size(0)

    return {
        "train_loss": total_loss / total,
        "train_accuracy": correct / total,
        "epoch_seconds": time.perf_counter() - start,
    }

@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    criterion = nn.CrossEntropyLoss()
    total_loss = correct = total = 0

    for x, y in loader:
        x = x.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)
        output = model(x)
        loss = criterion(output, y)

        total_loss += loss.item() * y.size(0)
        correct += (output.argmax(1) == y).sum().item()
        total += y.size(0)

    return {
        "val_loss": total_loss / total,
        "val_accuracy": correct / total,
    }
