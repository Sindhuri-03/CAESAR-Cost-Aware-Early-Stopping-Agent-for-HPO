import os
import pandas as pd
import matplotlib.pyplot as plt

from config import RESULTS_DIR, TOTAL_BUDGET, TARGET_ACCURACY

def evaluate_results(agent_df, baseline_df):
    os.makedirs(RESULTS_DIR, exist_ok=True)

    agent_best = float(agent_df["best_val_accuracy"].max())
    base_best = float(baseline_df["best_val_accuracy"].max())

    agent_cost = float(agent_df["trial_cost_usd"].sum())
    base_cost = float(baseline_df["trial_cost_usd"].sum())

    agent_target = agent_df[agent_df["best_val_accuracy"] >= TARGET_ACCURACY]
    base_target = baseline_df[baseline_df["best_val_accuracy"] >= TARGET_ACCURACY]

    summary = {
        "agent_best_validation_accuracy": agent_best,
        "random_search_best_validation_accuracy": base_best,
        "agent_total_simulated_cost_usd": agent_cost,
        "random_search_total_simulated_cost_usd": base_cost,
        "agent_trials_to_target": int(agent_target["trial"].min()) if len(agent_target) else None,
        "random_search_trials_to_target": int(base_target["trial"].min()) if len(base_target) else None,
        "budget_usd": TOTAL_BUDGET,
        "cost_savings_usd": base_cost - agent_cost,
        "cost_savings_percent": ((base_cost - agent_cost) / base_cost * 100) if base_cost else None
    }

    pd.DataFrame([summary]).to_csv(
        os.path.join(RESULTS_DIR, "summary.csv"), index=False
    )

    plt.figure(figsize=(7, 4))
    plt.bar(["Random Search", "LLM Agent"], [base_best, agent_best])
    plt.ylabel("Best Validation Accuracy")
    plt.title("Best Validation Accuracy Comparison")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULTS_DIR, "accuracy_comparison.png"), dpi=200)
    plt.close()

    plt.figure(figsize=(7, 4))
    plt.bar(["Random Search", "LLM Agent"], [base_cost, agent_cost])
    plt.ylabel("Simulated Cost (USD)")
    plt.title("Total Simulated Search Cost")
    plt.tight_layout()
    plt.savefig(os.path.join(RESULTS_DIR, "cost_comparison.png"), dpi=200)
    plt.close()

    log_path = os.path.join(RESULTS_DIR, "agent_decision_log.csv")
    if os.path.exists(log_path):
        log = pd.read_csv(log_path)
        counts = log["decision"].value_counts()
        plt.figure(figsize=(7, 4))
        counts.plot(kind="bar")
        plt.ylabel("Count")
        plt.xlabel("Decision")
        plt.title("LLM Agent Decision Distribution")
        plt.tight_layout()
        plt.savefig(os.path.join(RESULTS_DIR, "decision_distribution.png"), dpi=200)
        plt.close()

    return summary
