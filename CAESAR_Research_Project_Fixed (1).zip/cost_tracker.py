class CostTracker:
    def __init__(self, price_per_hour):
        self.price_per_hour = price_per_hour
        self.total_seconds = 0.0

    def add_seconds(self, seconds):
        self.total_seconds += float(seconds)

    @property
    def total_cost(self):
        return self.total_seconds / 3600.0 * self.price_per_hour

    def remaining(self, budget):
        return max(0.0, budget - self.total_cost)
