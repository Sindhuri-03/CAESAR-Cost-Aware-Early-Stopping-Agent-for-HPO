import torch
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms
from config import DATA_DIR, TRAIN_SPLIT_SEED, NUM_WORKERS

def get_data_loaders(batch_size):
    train_tfms = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2470, 0.2435, 0.2616)),
    ])
    eval_tfms = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2470, 0.2435, 0.2616)),
    ])

    train_aug = datasets.CIFAR10(DATA_DIR, train=True, download=True, transform=train_tfms)
    train_eval = datasets.CIFAR10(DATA_DIR, train=True, download=False, transform=eval_tfms)
    test_set = datasets.CIFAR10(DATA_DIR, train=False, download=True, transform=eval_tfms)

    generator = torch.Generator().manual_seed(TRAIN_SPLIT_SEED)
    permutation = torch.randperm(len(train_aug), generator=generator).tolist()
    train_idx = permutation[:45000]
    val_idx = permutation[45000:50000]

    train_set = Subset(train_aug, train_idx)
    val_set = Subset(train_eval, val_idx)

    common = dict(num_workers=NUM_WORKERS, pin_memory=torch.cuda.is_available())
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True, **common)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False, **common)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False, **common)
    return train_loader, val_loader, test_loader
