import json
import os
from config import CHECKPOINT_DIR

def save_trial_checkpoint(trial_number, payload):
    os.makedirs(CHECKPOINT_DIR, exist_ok=True)
    path = os.path.join(CHECKPOINT_DIR, f"trial_{trial_number:03d}.json")
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
    return path

def save_search_state(payload):
    os.makedirs(CHECKPOINT_DIR, exist_ok=True)
    path = os.path.join(CHECKPOINT_DIR, "search_state.json")
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)
    return path
