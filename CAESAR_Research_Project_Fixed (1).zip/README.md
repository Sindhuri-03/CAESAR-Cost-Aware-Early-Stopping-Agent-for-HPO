# CAESAR — Research-Ready Implementation

This version extends the supplied paper implementation with the missing evaluation and research components.

## Included

- Optuna TPE hyperparameter search
- ResNet18 adapted for CIFAR-10
- 45k/5k train/validation split
- Held-out 10k CIFAR-10 test set
- Epoch-level training
- Simulated dollar cost tracking
- LLM controller with CONTINUE / EXTEND / KILL
- Random-search baseline
- Global budget guard
- Trial/search checkpoint files
- Agent decision + reason logging
- Trials-to-target metric
- Cost-savings metric
- Held-out test evaluation
- Final CSV tables
- Final plots

## Important semantics

The nominal training horizon is 5 epochs and the maximum is 10.

- CONTINUE: permits one additional epoch at the nominal boundary.
- EXTEND: grants the remaining extended horizon up to epoch 10.
- KILL: stops the trial.

This makes EXTEND operationally distinct from CONTINUE.

## Colab

1. Upload this ZIP.
2. Extract it.
3. Install:

```python
!pip install -q -r /content/CAESAR_Research_Project_ResearchReady/requirements.txt
```

4. Put `OPENAI_API_KEY` in Colab Secrets and enable notebook access.
5. Add the project path:

```python
import sys
sys.path.insert(0, "/content/CAESAR_Research_Project_ResearchReady")
```

6. Run:

```python
from main import main
main()
```

## Outputs

`results/` contains:

- `summary.csv`
- `agent_trial_summary.csv`
- `agent_decision_log.csv`
- `random_search_results.csv`
- `held_out_test_results.csv`
- `accuracy_comparison.png`
- `cost_comparison.png`
- `decision_distribution.png`

`checkpoints/` contains per-trial JSON records and global search state.

## Important research interpretation

Do not claim the LLM agent improves accuracy unless the actual experiment supports it. The experiment should be discussed using cost, trials-to-target, validation accuracy, held-out test accuracy, and decision-log analysis together.

The checkpoint files provide audit/recovery information, but this version does not promise exact mid-epoch model-state restoration after a Colab runtime is lost.
