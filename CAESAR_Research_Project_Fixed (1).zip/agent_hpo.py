import csv
import os
import pandas as pd
import torch
import optuna

from config import *
from data import get_data_loaders
from model import build_model
from training import make_optimizer, train_one_epoch, evaluate
from cost_tracker import CostTracker
from agent import LLMEarlyStoppingAgent
from checkpoint import save_trial_checkpoint, save_search_state

LOG_PATH = os.path.join(RESULTS_DIR, "agent_decision_log.csv")

FIELDS = [
    "trial","epoch","learning_rate","batch_size","optimizer","weight_decay",
    "train_accuracy","val_accuracy","delta_accuracy","best_val_accuracy",
    "epoch_seconds","trial_cost_usd","global_cost_usd","remaining_budget_usd",
    "decision","reason"
]

def append_log(row):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    exists = os.path.exists(LOG_PATH)
    with open(LOG_PATH, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        if not exists:
            writer.writeheader()
        writer.writerow({k: row.get(k, "") for k in FIELDS})

def run_agent_hpo(device):
    os.makedirs(RESULTS_DIR, exist_ok=True)

    # Start a clean log for a deliberate fresh experiment.
    if os.path.exists(LOG_PATH):
        os.remove(LOG_PATH)

    agent = LLMEarlyStoppingAgent()
    global_tracker = CostTracker(GPU_PRICE_PER_HOUR)
    trial_records = []

    study = optuna.create_study(
        direction="maximize",
        sampler=optuna.samplers.TPESampler(seed=SEED)
    )

    def objective(trial):
        if global_tracker.total_cost >= TOTAL_BUDGET:
            raise optuna.TrialPruned("Global budget exhausted before trial start.")

        params = {
            "learning_rate": trial.suggest_float("learning_rate", 1e-4, 1e-1, log=True),
            "batch_size": trial.suggest_categorical("batch_size", [32, 64, 128]),
            "optimizer": trial.suggest_categorical("optimizer", ["SGD", "Adam"]),
            "weight_decay": trial.suggest_float("weight_decay", 1e-5, 1e-2, log=True),
        }

        train_loader, val_loader, _ = get_data_loaders(params["batch_size"])
        model = build_model().to(device)
        optimizer = make_optimizer(model, params)

        trial_tracker = CostTracker(GPU_PRICE_PER_HOUR)
        best_acc = -1.0
        best_epoch = 0
        prev_acc = 0.0
        allowed_epochs = NOMINAL_EPOCHS
        decision = "CONTINUE"
        reason = "Initial training."

        for epoch in range(1, MAX_EPOCHS + 1):
            if global_tracker.total_cost >= TOTAL_BUDGET:
                decision = "BUDGET_EXHAUSTED"
                break

            train_m = train_one_epoch(model, train_loader, optimizer, device)
            val_m = evaluate(model, val_loader, device)

            trial_tracker.add_seconds(train_m["epoch_seconds"])
            global_tracker.add_seconds(train_m["epoch_seconds"])

            acc = val_m["val_accuracy"]
            delta = acc - prev_acc

            if acc > best_acc:
                best_acc = acc
                best_epoch = epoch

            if acc >= TARGET_ACCURACY:
                decision = "TARGET_REACHED"
                reason = "Target validation accuracy reached."
            elif epoch >= allowed_epochs:
                context = {
                    "epoch": epoch,
                    "validation_accuracy": acc,
                    "delta_accuracy": delta,
                    "best_validation_accuracy": best_acc,
                    "trial_cost_usd": trial_tracker.total_cost,
                    "global_cost_usd": global_tracker.total_cost,
                    "remaining_budget_usd": global_tracker.remaining(TOTAL_BUDGET),
                    "learning_rate": params["learning_rate"],
                    "batch_size": params["batch_size"],
                    "optimizer": params["optimizer"],
                    "weight_decay": params["weight_decay"],
                    "nominal_epochs": NOMINAL_EPOCHS,
                    "max_epochs": MAX_EPOCHS
                }

                decision, reason = agent.decide(context)

                if decision == "EXTEND":
                    allowed_epochs = MAX_EPOCHS
                elif decision == "CONTINUE" and epoch < MAX_EPOCHS:
                    allowed_epochs = epoch + 1
                elif decision == "KILL":
                    pass

            row = {
                "trial": trial.number,
                "epoch": epoch,
                **params,
                "train_accuracy": train_m["train_accuracy"],
                "val_accuracy": acc,
                "delta_accuracy": delta,
                "best_val_accuracy": best_acc,
                "epoch_seconds": train_m["epoch_seconds"],
                "trial_cost_usd": trial_tracker.total_cost,
                "global_cost_usd": global_tracker.total_cost,
                "remaining_budget_usd": global_tracker.remaining(TOTAL_BUDGET),
                "decision": decision,
                "reason": reason
            }
            append_log(row)

            print(
                f"Trial {trial.number:02d} Epoch {epoch:02d} "
                f"acc={acc:.4f} cost=${trial_tracker.total_cost:.5f} "
                f"global=${global_tracker.total_cost:.5f} decision={decision}"
            )

            save_trial_checkpoint(trial.number, {
                "trial": trial.number,
                "params": params,
                "last_epoch": epoch,
                "best_val_accuracy": best_acc,
                "best_epoch": best_epoch,
                "trial_cost_usd": trial_tracker.total_cost,
                "global_cost_usd": global_tracker.total_cost,
                "decision": decision,
                "reason": reason
            })

            trial.report(best_acc, epoch)

            prev_acc = acc

            if decision in {"KILL", "TARGET_REACHED", "BUDGET_EXHAUSTED"}:
                break

        record = {
            "trial": trial.number,
            **params,
            "best_val_accuracy": best_acc,
            "best_epoch": best_epoch,
            "trial_cost_usd": trial_tracker.total_cost,
            "stopped_reason": decision,
            "global_cost_usd_after_trial": global_tracker.total_cost
        }
        trial_records.append(record)

        save_search_state({
            "mode": "agent",
            "completed_trials": len(trial_records),
            "global_cost_usd": global_tracker.total_cost,
            "budget_usd": TOTAL_BUDGET
        })

        if best_acc < 0:
            raise optuna.TrialPruned("No valid epoch completed.")

        return best_acc

    try:
        study.optimize(objective, n_trials=N_TRIALS)
    except KeyboardInterrupt:
        print("Interrupted. CSV logs/checkpoints contain completed progress.")

    df = pd.DataFrame(trial_records)
    df.to_csv(os.path.join(RESULTS_DIR, "agent_trial_summary.csv"), index=False)
    return study, df
