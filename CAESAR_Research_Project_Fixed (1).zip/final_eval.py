import os
import pandas as pd

from config import RESULTS_DIR, FINAL_EPOCHS
from data import get_data_loaders
from model import build_model
from training import make_optimizer, train_one_epoch, evaluate

def select_best_configuration(agent_df):
    row = agent_df.loc[agent_df["best_val_accuracy"].idxmax()]
    params = {
        "learning_rate": float(row["learning_rate"]),
        "batch_size": int(row["batch_size"]),
        "optimizer": str(row["optimizer"]),
        "weight_decay": float(row["weight_decay"])
    }
    selected_epoch = int(row["best_epoch"])
    return params, selected_epoch

def final_test_evaluation(agent_df, device):
    params, selected_epoch = select_best_configuration(agent_df)
    epochs = FINAL_EPOCHS or selected_epoch

    train_loader, val_loader, test_loader = get_data_loaders(params["batch_size"])
    model = build_model().to(device)
    optimizer = make_optimizer(model, params)

    val_history = []
    for epoch in range(1, epochs + 1):
        train_one_epoch(model, train_loader, optimizer, device)
        val_m = evaluate(model, val_loader, device)
        val_history.append(val_m["val_accuracy"])
        print(f"[final] Epoch {epoch:02d} val_acc={val_m['val_accuracy']:.4f}")

    test_m = evaluate(model, test_loader, device)

    result = {
        "selected_learning_rate": params["learning_rate"],
        "selected_batch_size": params["batch_size"],
        "selected_optimizer": params["optimizer"],
        "selected_weight_decay": params["weight_decay"],
        "retraining_epochs": epochs,
        "final_validation_accuracy": val_history[-1],
        "held_out_test_accuracy": test_m["val_accuracy"],
        "held_out_test_loss": test_m["val_loss"]
    }

    pd.DataFrame([result]).to_csv(
        os.path.join(RESULTS_DIR, "held_out_test_results.csv"),
        index=False
    )
    return result
