"""
run_multi_seed.py

Runs the full agent-vs-baseline comparison across multiple seeds.
A single run has no variance to test statistical significance against —
this is what actually produces the N>=3 paired samples needed for the
paired t-test / Wilcoxon test in analyze_results.py.

Usage:
    python run_multi_seed.py --seeds 42 43 44 45 46
"""

import argparse
import os
import shutil
import torch

import config
from agent_hpo import run_agent_hpo
from baseline import run_random_baseline


def main(seeds):
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is not available. Add it through Colab Secrets.")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Device:", device)

    os.makedirs("results/multi_seed", exist_ok=True)

    for seed in seeds:
        print(f"\n{'='*60}\nSEED {seed}\n{'='*60}")
        config.SEED = seed
        config.TRAIN_SPLIT_SEED = seed

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

        _, agent_df = run_agent_hpo(device)
        _, baseline_df = run_random_baseline(device)

        agent_df.to_csv(f"results/multi_seed/agent_seed{seed}.csv", index=False)
        baseline_df.to_csv(f"results/multi_seed/baseline_seed{seed}.csv", index=False)

        # keep the per-seed decision log too, for qualitative examples later
        log_src = os.path.join(config.RESULTS_DIR, "agent_decision_log.csv")
        if os.path.exists(log_src):
            shutil.copy(log_src, f"results/multi_seed/agent_decision_log_seed{seed}.csv")

        print(f"Seed {seed} done: agent_best={agent_df['best_val_accuracy'].max():.4f} "
              f"baseline_best={baseline_df['best_val_accuracy'].max():.4f}")

    print("\nAll seeds complete. Run analyze_results.py next.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44, 45, 46])
    args = parser.parse_args()
    main(args.seeds)
